package com.example.learn;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.button.MaterialButton;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    MaterialButton submit, create;
    EditText username_field, password_field;
    String url = "https://crud777.000webhostapp.com/login.php";
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        submit = findViewById(R.id.submit_btn);
        create = findViewById(R.id.create_btn);

        username_field = findViewById(R.id.edt_username);
        password_field = findViewById(R.id.edt_password);



        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registerActivity = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(registerActivity);
            }
        });


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                
                final String username = username_field.getText().toString();
                final String password = password_field.getText().toString();


                if (TextUtils.isEmpty(username) && TextUtils.isEmpty(password))
                {
                    Toast.makeText(MainActivity.this, "Oops You Forgot To Fill in Some Fields", Toast.LENGTH_SHORT).show();
                }
                else{



                    StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                           if (response.equalsIgnoreCase("logged in successfully")){
                               username_field.setText("");
                               password_field.setText("");
                               Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();


                           }else{
                               Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();
                           }

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Toast.makeText(MainActivity.this, error.getMessage().toString(), Toast.LENGTH_SHORT).show();


                        }
                    }){
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {

                            Map<String,String> param = new HashMap<String, String>();
                            param.put("name",username);
                            param.put("password",password);

                            return param;


                        }
                    };


                    RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
                    requestQueue.add(request);



                }


            }
        });



    }
}