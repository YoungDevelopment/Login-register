package com.example.learn;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.button.MaterialButton;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    MaterialButton login, create;
    EditText username_field, password_field, email_field;
    String url = "https://crud777.000webhostapp.com/register.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        login = findViewById(R.id.login_btn);
        create = findViewById(R.id.create_btn);

        username_field = findViewById(R.id.edt_username);
        password_field = findViewById(R.id.edt_password);
        email_field= findViewById(R.id.edt_email);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent loginActivity = new Intent(RegisterActivity.this,MainActivity.class);
                startActivity(loginActivity);
            }
        });

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String username = username_field.getText().toString();
                final String password = password_field.getText().toString();
                final String email = email_field.getText().toString();


                if (TextUtils.isEmpty(username) && TextUtils.isEmpty(password) && TextUtils.isEmpty(email))
                {
                    Toast.makeText(RegisterActivity.this, "Oops You Forgot To Fill in Some Fields", Toast.LENGTH_SHORT).show();
                }
                else{
                    StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            username_field.setText("");
                            password_field.setText("");
                            email_field.setText("");
                            Toast.makeText(RegisterActivity.this, response, Toast.LENGTH_SHORT).show();

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(RegisterActivity.this, error.getMessage().toString(), Toast.LENGTH_SHORT).show();
                        }
                    }){
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {
                            Map<String,String> param = new HashMap<String, String>();
                            param.put("name", username);
                            param.put("password",password);
                            param.put("email",email);

                            return param;



                        }
                    };


                    RequestQueue requestQueue = Volley.newRequestQueue(RegisterActivity.this);
                    requestQueue.add(request);

                }

            }
        });

    }
}