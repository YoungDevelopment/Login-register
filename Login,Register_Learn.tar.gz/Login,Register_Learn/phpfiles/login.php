<?php 
		$con=mysqli_connect("localhost","id14624967_beast0340","*}JLKlxR>a3g7+9i","id14624967_beast");

		$email = $_POST["name"];
		$password = $_POST["password"];

		$sql = "SELECT * FROM studentmanagementsystem WHERE  name = '$name' AND password = '$password'";
		$result = mysqli_query($con,$sql);
		
		if($result->num_rows > 0){
			echo "logged in successfully" ;
		}else{
  			 echo "user not found";
}
?>