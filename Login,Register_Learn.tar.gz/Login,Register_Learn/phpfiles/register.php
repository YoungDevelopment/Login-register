<?php 
	$con=mysqli_connect("localhost","id14624967_beast0340","*}JLKlxR>a3g7+9i","id14624967_beast");
	
	$name = $_POST["name"];
	$email = $_POST["email"];
	$password =$_POST["password"];

	$sql = "INSERT INTO studentmanagementsystem(name,email,password) VALUES ('$name','$email','$password')";
	$result = mysqli_query( $con,$sql );
	
	if($result) {
		echo "registered successfully";
	}
	else {
		echo "some error occured";
	}
?>